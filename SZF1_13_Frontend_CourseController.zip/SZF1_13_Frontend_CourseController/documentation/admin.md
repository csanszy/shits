# Admin felület

Az admin a következőket tudja csinálni:
- MD file-ok szerkesztése, törlése, feltöltése
- Dokumentum kollekciók generálása
- Felhasználók menedzselése

Az admin nevezi ki a tanárokat, illetve szankcionálja a felhasználókat, tiltással, kirúgással vagy a szerkesztési jog megvonásával.
Admint csak a fejlesztők neveznek ki, a biztonság és a konzisztencia érdekében.
Az admin feladata a hozzáférés-szabályozás, csak ő tudja nyilvánossá tenni a már meglévő dokumentációkat a szenzitív információk védelmének érdekében.
Az admin egy külön felületen dolgozik, melyhez másnak hozzáférése nincs.
Ez a szerep a tanulón és a diákon kívül szerepel, tehát admin nem lehet diák sem tanár.
Nincs lehetősége az adminnak direktben szerkeszteni a felhasználók információit.