Tartalomjegyzék 


Tartalomjegyzék feladatai, céljai: 

-Az oldalon található címek sorban való összegzése 
-Bizonyos szövegrészek elérése gyorsan


A tartalomjegyzék olyan sorrendben írja a ki a címeket ahogyan azt a szöveg elolvasása közben megtaláljuk. 
Az alcímeket is tökéletesen láthatjuk mivel azok a tartalomjegyzékben bentebb kezdődnek, mint a fő címek. 
Ezeket az oldalon kisebb betűmérettel találjuk. 
