- A tanárok azok akik képesek a megadott tantárgyakon belül képes posztolni tananyagot. 

- A tanárok viszont nem képesek más tantárgyba betenni tananyagot, csak ha megkapják a szükséges engedélyeket.

- Lehetséges lesz a tanárnak kiadni egy feladatot az oldalra és ahoz a feladathoz fájt csatolni segítségnek/kiindulási pontnak.

- Képesek lesznek a tanárok felrakni képeket a tananyagba a vizuális megjelenítés segítésére.

- A tanároknak szükséges lesz a belépés.