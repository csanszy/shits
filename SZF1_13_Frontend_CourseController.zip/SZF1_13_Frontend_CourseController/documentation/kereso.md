Kereső funkció

A kereső lehetővé teszi, hogy a felhasználó gyorsabban megtalálja a tananyagot. 
A keresés eredményei dinamikusan frissülnek a beírt szavak alapján, így a felhasználó azonnal láthatja a találatokat. 
A keresőmező minden oldalon elérhető és mindenki számára elérhető (tanar, diak, admin). 
