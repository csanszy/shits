#  Userek közötti chat 

Hasznos funkció, megkönnyebbíti a tanár-diák, diák-diák közötti kommunikációt.
Az egész lényegében egy nagy google chat lenne, a diákok felvett kurzusok alapján látják a nekik való szobákat, a tanár vice versa ugyan így.
Nyílván a Rgazda tudja ezeket módosítani szükségek szerint, illetve miután aktualitását vesztette a chat, akkor a tanárnak mentődik egy archivált verzióban is, ha kellene.

*Funkciók* (perhaps)
 * említett kapcsolattartási egyszerűség
* fájlok megemlítésének lehetősége (pl ha valakinek kérdése van)
* csoportos témabeszélgetések (threadek)
