A felhasználók képesek megtekinteni minden olyan oldalt, amihez van engedélye.
A felhasználók szerkeszthetnek vagy kimásolhatnak minden markdownt.
Megtekinthetik a tanárok által kitett anyagokat, ha abba csoportba a tanár berakta a felhasználót.
Az anyagok alá tudnak írni megjegyzést.
A felhasználók meg tudják nézni a tantargyakat, ezt megtehetik bejelentkezés nélkül is.
Látják az adott órát, ami jelenleg az óra szerint zajlik.




Készítette: Huszár Imre