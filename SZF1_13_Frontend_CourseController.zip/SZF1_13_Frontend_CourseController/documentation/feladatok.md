Admin - Gyula
User - Imre Herceg  
Tanar - Gabor  
Markdown generacio  
[Markdown editor](./markdown-editor.md) Barna  
Sidebars - Husi (Smut Paladin Alexander)  
Page navigation (bal oldali menusav) - Barta  
Tartalomjegyzek - Dávid  
Kereso funkcio - Bogyó  
Kepfeltoltes frontend - Kevin

Pelda egy kesz oldalrol:  
https://okt.inf.szte.hu/prog2/gyakorlat/gyak10/tananyag/
