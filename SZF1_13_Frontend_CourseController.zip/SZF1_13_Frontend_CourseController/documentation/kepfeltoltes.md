Képfeltöltés frontend

Céljai: 
- A képfeltöltések célja a frontendben az, hogy az oldalon több dolgot jelenítsünk meg kép formában, amellyel szebbé és stílusosabbá tegyük az oldalt.
- Emellett a képek fotmáját, méretét és kinézetét is tudjuk szerkeszteni, hogy illeszkedjen az oldalhoz.
