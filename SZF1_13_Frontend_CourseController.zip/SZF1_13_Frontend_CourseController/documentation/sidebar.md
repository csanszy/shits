Sidebar

A sidebar a lap két szélén található, függőleges sáv, navigációs elemeket tartalmaz.
Célja hogy könnyebben lehessen navigálni az oldalon és a tartalomjegyzék itt helyezkedik el.
Áttekinthetőséget segíti , egy helyen található az oldal teljes struktúrája. 
Fontos dolgok (pl gyakorlatok, linkek) egy helyen található. 
Jobb felhasználói élményt nyújt, könnyebbé teszi az oldalon való tájékozódást.
