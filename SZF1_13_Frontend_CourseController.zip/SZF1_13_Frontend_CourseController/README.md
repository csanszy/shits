Jani Patrik terv: https://www.figma.com/design/JkvpapuM2XgTM6wulINPWS/Pollak-Project?node-id=0-1&t=8H0PuoVi9xUXhfUZ-1 \
Gere Csanád terv: https://www.figma.com/design/7tZ9heZPsNwgWYalnKcNpI/okt-figma-design?node-id=0-1&node-type=canvas&t=tQRAlLfJSu8VL8Bu-0 \
Bene Dominik terv: https://www.figma.com/design/OMTYyzeOvpP29VktpkhsyK/Pollak-Project?node-id=0-1&node-type=canvas&t=Ze24CO2WwCtIw4jY-0 \
The project's Figma design is available here: https://www.figma.com/design/KcVklY2NsKUyrEO6JppxGf/Untitled?node-id=1-151&node-type=frame&t=DKxvQwrFHjXRLUnE-0

[bg.txt](https://github.com/user-attachments/files/17630132/bg.txt)
