# Server

Run the server with auto-reload

```bash
npm run dev
```

> Don't forget to install dependencies!  
> `npm i`
