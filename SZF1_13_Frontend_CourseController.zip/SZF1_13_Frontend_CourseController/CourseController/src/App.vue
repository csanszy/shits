<script setup>
import UserIcon from "./Components/NavigationComponents/UserIcon.vue";

</script>

<template>

  <RouterView />

</template>

<style scoped>

</style>
