

<template>
    <div class="flex flex-col justify-center items-center h-screen text-center bg-gradient-to-r from-blue-500 to-purple-500">
        <h1 class="text-6xl">404</h1>
        <p class="text-xl">Page not found</p>
        <router-link to="/">
            <button class="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700">
                Go home
            </button>
            
        </router-link>
    </div>
</template>


